//Rain effect. Each raindrop is a member
// of a numbered "drops" structure.
//For STM8S103 it manages to process up to 
//10 raindrops.

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <time.h>
//#include <stack.h>
//#include <iostream>
//#include <vector>
//#include <string>
//#include <cstring>

//constants
 const __uint16_t LEN_all= 120;
 const __uint8_t DR_Quan= 6;
 const __uint8_t T_life= 10;
 const __uint8_t T_wave= 10;
 const __uint8_t T_spl= 10;
 const __uint16_t  DT_max=120;
 const __uint8_t  DX_max=120;

//vars
 __uint8_t t_dif, x_dif, vert;
 __uint16_t x_pos, t_pos;
 __uint8_t w_max;
//buffers
 __uint8_t temp;
 __uint16_t tempw;

//Arreys
 
 __uint8_t color[3];
 __uint8_t cur[3];//send data to WS28xx
 
//---------------------------
//Structures and types
//---------------------------

struct bit_s {
unsigned h_c:1;//handl. is compl.
unsigned delta_dsr:1;
             } flag ;
//--------------------------
//-------Functions---------
//------------------------
 void w_send()
 
 {
 //send data to WS28xx, created in ASM
 };
//------------------------------
 
//=======================
//=======================


struct dev {
    __uint8_t color[3];
    __uint16_t x_app;
    __uint16_t t_app;
       }drop[20] ;

    struct dev *p= drop;

//-----MAin------------    

void   main()  
{      
  unsigned char i,j ;
  
//набор
//preset
 cur[i]= 0,0,0;

for (;;t_pos++) 
 {
      if (t_pos==0xffff) t_pos=0;
//------------------------------      
//------check & regeneration----
        for(i=0;i=DR_Quan-1;i++)
         {
         //t_dif=t_pos- (p->t_app);
         t_dif=t_pos- (drop[i].t_app);
         if (t_dif>T_life) {
         // regen. of data
         //color
         switch (temp=rand()% 8)
         {
      case 0: //black
            drop[i].color[j]=0,0,0; break;                 
      case 1: //red
            drop[i].color[j]=255,0,0; break;                 
      case 2: //green
             drop[i].color[j]=0,255,0; break;
       case 3: //blue
            drop[i].color[j]=0,0,255; break;
       case 4: //cyan
            drop[i].color[j]=127,127,0; break;
       case 5: //yellow
             drop[i].color[j]=127,0,127; break;
      case 6: //purple
            drop[i].color[j]=127,0,127; break;
      case 7: //white
            drop[i].color[j]=85,85,85; break;
         }

         tempw=rand()% 0xffff;
         drop[i].x_app=tempw/DX_max;
         tempw=rand()% 0xffff; 
         drop[i].t_app=tempw/DT_max;
         }
        } 
//--------------------------------- 

  for (x_pos=0;x_pos=LEN_all ; x_pos++)
           {  
for (i=0;i=DR_Quan;i++ ) { ;
         t_dif=t_pos-drop[i].t_app;
         x_dif=(x_pos-drop[i].x_app);
         (x_dif>0) ? x_dif : -x_dif;//ABS value
   if ((t_dif<0)||(t_dif>(T_life+T_spl)))  goto d_e ;
   if (x_dif>T_life)    goto d_e ; //far
   if ((t_dif<T_spl)||(!x_dif)) { //splash
      cur[0]=255;cur[1]=255;cur[2]=255; goto d_e;}
//wafe

//w_max=(X)*
//(T_life-t_dif+T_spl)
//;/T_live
      vert=t_dif - T_spl;
      temp=x_dif-vert;(temp>0) ? temp: -temp;
   //if |x_dif-vert|>#LEN_wave
      if (temp>T_wave) {cur[0]=0;cur[1]=0;cur[2]=0; goto d_e;}
//color  handl.
        for (j=0;j=2;j++)  {
        w_max=drop[i].color[j]*(T_life-t_dif+T_spl)/T_life;
        cur[j]=w_max>>temp;
                            }
                          }
d_e:
                      }
// function transmittes RGB-data of current picsel
//to information input WS28xx.
        w_send(*cur) ;
//During this time, the LEDs with the specified RGB light up
        sleep(20);  
      }                            
 }
        
   


 
