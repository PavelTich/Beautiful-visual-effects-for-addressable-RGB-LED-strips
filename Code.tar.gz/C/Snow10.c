//"Snow" effect. 

#include <stdlib.h>
#include <stdio.h>
#include <ctype.h>
#include <time.h>

//-----Constansts-------
const	 LEN_all= 120;
const SL_min =1;
//---vars--------
__uint8_t cur[3]; //RGB for send.
//----adjustable------
 __uint8_t  br; //overall bright
 __uint8_t  sp; //effects speed 
//---------------
//----Counters---------
 __uint8_t len_cnt;x_pos;
 __uint8_t sn_pnt ; //snow pointer
//----buffers----------
__uint8_t temp;
//---------------------

//-----arrays---------

//picsel file

 __uint8_t pics[240]; //2m strip=240 picsels   

 
//-----------------------

//-----Functions-------
//------------------------
 void w_send()
 {
 //send. data to WS28xx, created in ASM
 //ref. w_send.asm
 }
//------------------------------
//-----Main------------    

void   main() 
{
  unsigned short i,j ;

  do {

//regen. data file
    for (i=0;i=LEN_all; i++)
    { 
   pics[i]= rand()% 8;
    }
//Calc. cur. data
for (i=0;i=LEN_all; i++) {
  switch (pics[i])
         {
      case 0: //black
       cur[j]=0,0,0;  break;              
      case 1: //red
       cur[j]=255*br,0,0;  break;                  
      case 2: //green
       cur[j]=0,255*br,0;  break;
       case 3: //blue
        cur[j]=0,0,255*br;  break;
       case 4: //cyan
         cur[j]=0,255*br,255*br;  break;
       case 5: //yellow
         cur[j]=255*br,255*br,0;  break;   
      case 6: //purple
         cur[j]=255*br,0,255*br;  break; 
      case 7: //white
         cur[j]=85*br,85*br,85*br;  break; 
         }
    }

//During this time, the LEDs with the specified RGB light up
      w_send(*cur) ;sleep(sp); 

  }while (1);
}



